﻿using Godot;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Utils
{
    public class TestUtils
    {

        public TestUtils()
        {

        }

        public void Test()
        {
            GD.Print("我是Utils方法");
        }
    }
}
