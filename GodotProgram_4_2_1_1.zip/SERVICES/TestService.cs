﻿using Godot;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Services
{
    public class TestService
    {
        public TestService() { }
        public void Test()
        {
            GD.Print("我是TestService方法");
        }
    }
}
